class Dog < ActiveRecord::Base
end
